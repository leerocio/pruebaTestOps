<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Parent framehtml1body1</name>
   <tag></tag>
   <elementGuidId>a396d270-8a7c-4161-a7e6-1b7f14596b47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Parent frame']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Parent frame/html[1]/body[1]&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>5c8d6fe9-6f8c-4bdf-83b5-5fe315decd27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Parent frame/html[1]/body[1]</value>
      <webElementGuid>316eb584-331f-446d-9a87-7bc261b8f710</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
      <webElementGuid>3105074c-5053-49a7-8ea6-d4b785c1cfad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_DEMOQA/Page_DEMOQA/iframe_Nested Frames_frame1</value>
      <webElementGuid>3b156f2d-5098-4678-a541-2c5cc9e7d71f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Parent frame']/parent::*</value>
      <webElementGuid>1a659262-4a65-4253-b2d1-3711398704bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>d902d372-5fd7-40e8-8e21-f302a67582d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = 'Parent frame/html[1]/body[1]' or . = 'Parent frame/html[1]/body[1]')]</value>
      <webElementGuid>1ef97838-726d-43c6-8992-5e3582cbc5f2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
