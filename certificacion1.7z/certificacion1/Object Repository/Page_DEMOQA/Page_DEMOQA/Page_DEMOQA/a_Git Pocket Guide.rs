<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Git Pocket Guide</name>
   <tag></tag>
   <elementGuidId>f3bce78f-213a-4aa1-adf8-b438d248847c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='see-book-Git Pocket Guide']/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Git Pocket Guide&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cb89e0f5-fcd1-47b9-a9ec-5f5ded30f173</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/books?book=9781449325862</value>
      <webElementGuid>aa7053f5-a340-4b12-b25a-e25ec3c9934a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Git Pocket Guide</value>
      <webElementGuid>e0c5fc61-a398-4c27-aa04-c4fbf1490ab1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;see-book-Git Pocket Guide&quot;)/a[1]</value>
      <webElementGuid>5bf75481-a092-485a-b6b4-eb34e60befd0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='see-book-Git Pocket Guide']/a</value>
      <webElementGuid>a278aeeb-976b-4c09-93b6-88ba2b4c79fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Git Pocket Guide')]</value>
      <webElementGuid>08305724-54aa-4a08-a1fb-a30aab685770</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publisher'])[1]/following::a[1]</value>
      <webElementGuid>7803ea09-7756-42df-b719-d21383a1d430</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Author'])[1]/following::a[1]</value>
      <webElementGuid>c1170e06-1432-4975-9760-103d01b73e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Richard E. Silverman'])[1]/preceding::a[1]</value>
      <webElementGuid>35d19667-9c19-41a1-9bd9-c669c2fbf27d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Git Pocket Guide']/parent::*</value>
      <webElementGuid>a81998b8-175a-4294-8a1b-7960cdb2c9e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/books?book=9781449325862')]</value>
      <webElementGuid>9d0ff522-3e56-4039-89e7-4ba81a0f03c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/a</value>
      <webElementGuid>e1f0dbd0-de65-4e91-9176-17fa387f8df1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/books?book=9781449325862' and (text() = 'Git Pocket Guide' or . = 'Git Pocket Guide')]</value>
      <webElementGuid>48a76c2f-1bc1-4b2a-b999-70f89ed64107</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
