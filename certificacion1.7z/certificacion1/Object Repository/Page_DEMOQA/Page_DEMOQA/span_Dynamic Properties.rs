<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Dynamic Properties</name>
   <tag></tag>
   <elementGuidId>3b5be710-52ae-4fa4-b233-87f123518da7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#item-8 > span.text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='item-8']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dynamic Properties&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ee4a1e40-81c3-4827-80dc-23a2d357702c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>bffdeadb-1866-458a-ae3b-dc57159f6e71</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dynamic Properties</value>
      <webElementGuid>43304c42-f2b5-4859-8dc0-a69024f2156a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;body-height&quot;]/div[@class=&quot;container playgound-body&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 mt-4  col-md-3&quot;]/div[@class=&quot;left-pannel&quot;]/div[@class=&quot;accordion&quot;]/div[@class=&quot;element-group&quot;]/div[@class=&quot;element-list collapse show&quot;]/ul[@class=&quot;menu-list&quot;]/li[@id=&quot;item-8&quot;]/span[@class=&quot;text&quot;]</value>
      <webElementGuid>dc63eda5-e0a5-4718-a8de-e3d0a4ffcb75</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='item-8']/span</value>
      <webElementGuid>bdfea428-7fc3-4728-8c93-58699c8a9e7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload and Download'])[1]/following::span[1]</value>
      <webElementGuid>5c6d4d0b-fe7d-4c6f-ab72-125a4eb56d3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Broken Links - Images'])[1]/following::span[2]</value>
      <webElementGuid>ca981524-6b24-48fe-a78e-f476122c3e0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forms'])[1]/preceding::span[1]</value>
      <webElementGuid>c82f2771-67f8-4f28-9511-0b771fcc9bfc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Practice Form'])[1]/preceding::span[3]</value>
      <webElementGuid>99769f85-f655-4a50-9352-c8afdb752396</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Dynamic Properties']/parent::*</value>
      <webElementGuid>258bd45f-9a73-468b-8085-c1b7779b81ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/span</value>
      <webElementGuid>51969f3c-6c9c-4fed-a640-4262c63b034e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Dynamic Properties' or . = 'Dynamic Properties')]</value>
      <webElementGuid>5b3dbd39-6542-4c35-b160-4987196ab0f7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
