
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "test8.test08"() {
    (new test8()).test08()
}


def static "opendemoQa.keyword1"() {
    (new opendemoQa()).keyword1()
}


def static "test21.test21w"() {
    (new test21()).test21w()
}


def static "test10.test10t"() {
    (new test10()).test10t()
}


def static "test9.test09"() {
    (new test9()).test09()
}


def static "test11.test11t"() {
    (new test11()).test11t()
}
