<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>test suite 3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>41afa09e-c810-40ab-8817-c3e1cc58031c</testSuiteGuid>
   <testCaseLink>
      <guid>d4cd7c1a-c99d-4c0b-bbab-c8512947435c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/016 demoQa - click checkbox</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>df8eb3dd-db11-4781-a69a-95523e986541</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/demoQa16</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>df8eb3dd-db11-4781-a69a-95523e986541</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>text</value>
         <variableId>3cb220ec-bdf7-4477-8f23-c8d54cfd177b</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
