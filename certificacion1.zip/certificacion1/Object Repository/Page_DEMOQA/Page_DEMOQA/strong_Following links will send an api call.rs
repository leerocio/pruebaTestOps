<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Following links will send an api call</name>
   <tag></tag>
   <elementGuidId>b9318c06-ca36-4919-845b-465714568d92</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h5:nth-of-type(2) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='linkWrapper']/h5[2]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Following links will send an api call&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>29be7258-1697-4831-83f2-6c2ea00ce9a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Following links will send an api call</value>
      <webElementGuid>4f71cff1-26bd-4d5e-98a4-0d26d10ed7b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;linkWrapper&quot;)/h5[2]/strong[1]</value>
      <webElementGuid>ef422bfd-3d4c-45e1-a7d6-fcbf80db54d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='linkWrapper']/h5[2]/strong</value>
      <webElementGuid>ce602905-9466-4878-acbb-e1e6d9868a47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HomeDKfdz'])[1]/following::strong[1]</value>
      <webElementGuid>9fbb2eac-aa7b-45b5-a436-2e67e95ed444</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::strong[1]</value>
      <webElementGuid>a6c5bba1-5dd8-4918-a450-0b2a0f57c716</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Created'])[1]/preceding::strong[1]</value>
      <webElementGuid>6b453268-1548-4f7a-9514-2e5ade2e6c53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No Content'])[1]/preceding::strong[1]</value>
      <webElementGuid>4d8cde71-3f86-4165-98bf-d3ad00301eb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Following links will send an api call']/parent::*</value>
      <webElementGuid>4e648f46-0e7f-454a-9580-265e5ccdfbb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5[2]/strong</value>
      <webElementGuid>a3472201-ea1d-4d61-9326-9590ccc6734a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Following links will send an api call' or . = 'Following links will send an api call')]</value>
      <webElementGuid>185d8cf1-3e2e-4db5-bba5-7e2f4cd564b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
