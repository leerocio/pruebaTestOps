package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object urlCura
     
    /**
     * <p></p>
     */
    public static Object urlDemoQa
     
    /**
     * <p></p>
     */
    public static Object verifyElementDesktop
     
    /**
     * <p></p>
     */
    public static Object validateFullName
     
    /**
     * <p></p>
     */
    public static Object validateEmail
     
    /**
     * <p></p>
     */
    public static Object validateAddres
     
    /**
     * <p></p>
     */
    public static Object validatePermanentAddres
     
    /**
     * <p></p>
     */
    public static Object validateTextBox
     
    /**
     * <p></p>
     */
    public static Object Title
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            urlCura = selectedVariables['urlCura']
            urlDemoQa = selectedVariables['urlDemoQa']
            verifyElementDesktop = selectedVariables['verifyElementDesktop']
            validateFullName = selectedVariables['validateFullName']
            validateEmail = selectedVariables['validateEmail']
            validateAddres = selectedVariables['validateAddres']
            validatePermanentAddres = selectedVariables['validatePermanentAddres']
            validateTextBox = selectedVariables['validateTextBox']
            Title = selectedVariables['Title']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
