<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>test suite 2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>58d71415-0627-4e90-9f48-12294ebee276</testSuiteGuid>
   <testCaseLink>
      <guid>b0b8a6e0-343b-4311-9bb5-a694e561c30f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/014 demoQa - scroll and select Book store aplication</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>318ed70d-7345-4d13-99f9-6e0ae3f2d3fd</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/demoQA14</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>318ed70d-7345-4d13-99f9-6e0ae3f2d3fd</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>text</value>
         <variableId>9c69b8aa-98d6-4800-abae-3bd0fa91cc91</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
