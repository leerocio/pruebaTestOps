<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>test suite 1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>9b1db563-0a0d-4789-8601-ad361f0a153d</testSuiteGuid>
   <testCaseLink>
      <guid>41961176-f406-4dc9-87d0-efdbe4730f7d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/002 - Login</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>d0b28aa4-111f-4e2a-81bc-04924e456581</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/internalData</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>d0b28aa4-111f-4e2a-81bc-04924e456581</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>name</value>
         <variableId>9e3f62f9-09be-4695-b6e9-0524c1aacd06</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>ae6bbaeb-e201-40bf-8480-3ad40552e596</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/021 demoQa - buttons click me</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>bc1b3fae-9582-4647-92f8-447d81ced7e7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/022 demoQa - Links</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>f43293f5-6fc7-405e-80f0-5383a1185d12</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/50testCase/025 demoQa - Links - Validar text created</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
